import java.util.Scanner; // Import the Scanner class to read text files.
import java.util.Arrays; // Import the ArrayList class.
import java.io.FileReader; // Import the File class.
import java.io.FileWriter; // Import the FileWriter class.
import java.io.IOException; // Import the IOException class to handle errors.
import java.io.BufferedReader; // Importing the BufferedWriter class from the java.io package.
import java.io.BufferedWriter; // Importing the BufferedWriter class from the Java.io package,



public class FoodCenterManagement {
    private static final int MAX_BURGERS = 50; // Maximum number of burgers in stock.
    private static final int[] MAX_CUSTOMERS = {2, 3, 5};
    private static final int BURGERS_PER_CUSTOMER = 5; // Number of burgers served per customer.
    private static final int LOW_STOCK_THRESHOLD = 10;
    private static String[] queue1;
    private static String[] queue2;
    private static String[] queue3;
    private static String[] queueNames = {"Queue 1", "Queue 2", "Queue 3"};
    private static int[][] queueSeats = new int[3][5]; // Seats array for each queue.
    private static String[][] queueCustomers = new String[3][5]; // Customers array for each queue.
    private static int[] queueCount = new int[3]; // Number of customers in each queue.
    private static int stock = MAX_BURGERS;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;
        boolean invalidChoice = false;

        displayMenuOption();

        while (!exit) {
            if (!invalidChoice) {
                System.out.print("Enter your choice: ");
            }
            String input = scanner.nextLine().toUpperCase();

            switch (input) {
                case "100":
                case "VFQ":
                    viewAllQueues();
                    break;
                case "101":
                case "VEQ":
                    viewEmptyQueues();
                    break;
                case "102":
                case "ACQ":
                    addCustomer(scanner);
                    break;
                case "103":
                case "RCQ":
                    removeCustomer(scanner);
                    break;
                case "104":
                case "PCQ":
                    removeServedCustomer(scanner);
                    break;
                case "105":
                case "VCS":
                    sortCustomers();
                    break;
                case "106":
                case "SPD":
                    storeProgramData();
                    break;
                case "107":
                case "LPD":
                    loadProgramData();
                    break;
                case "108":
                case "STK":
                    viewRemainingBurgerStock();
                    break;
                case "109":
                case "AFX":
                    addBurgersToStock();
                    break;
                case "999":
                case "EXT":
                    System.out.println("Exiting the program....");
                    exit = true;
                    break;
                default:
                    invalidChoice = true;
                    continue;
            }
            System.out.println();
            invalidChoice = false;
        }
    }

    private static void displayMenuOption() {
        System.out.println("------------------------------------------------------");
        System.out.println("*****  WELCOME TO THE FOODIES FAVE FOOD CENTER   *****");
        System.out.println("------------------------------------------------------");

        System.out.println("**** MENU ****");
        System.out.println("100 or VFQ: view all Queues.");
        System.out.println("101 or VEQ: View all Empty Queues.");
        System.out.println("102 or ACQ: Add customer to a Queue.");
        System.out.println("103 or RCQ: Remove a customer from Queue. (From a specific location)");
        System.out.println("104 or PCQ: Remove a served customer.");
        System.out.println("105 or VCS: View Customers Sorted in alphabetical order (Do not use library sort routine)");
        System.out.println("106 or SPD: Store Program Data into files");
        System.out.println("107 or LPD: Load Program Data from file.");
        System.out.println("108 or STK: View Remaining burgers Stock.");
        System.out.println("109 or AFS: Add burgers to Stock.");
        System.out.println("999 or EXT: Exit the Program.");
        System.out.println("--------------------------------------------");
    }

    // Display the current occupancy of each food center queue.
    private static void printSeatingAreas() {
        System.out.println("*****************");
        System.out.println("*   Cashiers   *");
        System.out.println("*****************");

        for (int i = 0; i < queueNames.length; i++) {
            System.out.print(queueNames[i] + ":\t");
            for (int j = 0; j < MAX_CUSTOMERS[i]; j++) {
                if (j < queueCount[i]) {
                    System.out.print("O");
                } else {
                    System.out.print("X");
                }
            }
            System.out.println();
        }
        System.out.println("X-Not Occupied O-Occupied");
    }

    // Create a method called addCustomer.
    private static void addCustomer(Scanner scanner) {
        System.out.print("Enter customer name: ");
        String customerName = scanner.next();

        System.out.println("Select a queue to add the customer:");
        for (int i = 0; i < queueNames.length; i++) {
            System.out.println((i + 1) + ". " + queueNames[i]);
        }
        int queueChoice = scanner.nextInt();

        if (queueChoice < 1 || queueChoice > queueNames.length) {
            System.out.println("Invalid queue choice.");
            return;
        }

        int queueIndex = queueChoice - 1;
        if (queueCount[queueIndex] == MAX_CUSTOMERS[queueIndex]) {
            System.out.println("Queue is full. Customer cannot be added.");
            return;
        }

        int seatNumber = findNextAvailableSeat(queueIndex);
        if (seatNumber == -1) {
            System.out.println("No available seats in the selected queue.");
            return;
        }

        queueCustomers[queueIndex][seatNumber] = customerName;
        queueSeats[queueIndex][seatNumber] = seatNumber + 1;
        queueCount[queueIndex]++;

        printSeatingAreas();
        System.out.println("Customer '" + customerName + "' added to  " + queueNames[queueIndex] +
                ". Seat number: " + queueSeats[queueIndex][seatNumber] + ".");
    }

    private static int findNextAvailableSeat(int queueIndex) {
        for (int i = 0; i < MAX_CUSTOMERS[queueIndex]; i++) {
            if (queueCustomers[queueIndex][i] == null) {
                return i;
            }
        }
        return -1;
    }

    // Create a method called removeCustomer.
    private static void removeCustomer(Scanner scanner) {
        System.out.print("Enter queue number (1-" + queueNames.length + "): ");
        int queueChoice = scanner.nextInt();

        if (queueChoice < 1 || queueChoice > queueNames.length) {
            System.out.println("Invalid queue choice.");
            return;
        }

        int queueIndex = queueChoice - 1;
        System.out.print("Enter seat number (1-" + MAX_CUSTOMERS[queueIndex] + "): ");
        int seatChoice = scanner.nextInt();

        if (seatChoice < 1 || seatChoice > MAX_CUSTOMERS[queueIndex]) {
            System.out.println("Invalid seat choice.");
            return;
        }

        int seatIndex = seatChoice - 1;
        if (queueCustomers[queueIndex][seatIndex] == null) {
            System.out.println("No customer at the specified seat.");
            return;
        }

        String customerName = queueCustomers[queueIndex][seatIndex];
        queueCustomers[queueIndex][seatIndex] = null;
        queueSeats[queueIndex][seatIndex] = 0;
        queueCount[queueIndex]--;
        queueSeats[queueIndex][seatIndex] = seatIndex + 1;
        printSeatingAreas();

        System.out.println("Remove customer '" + customerName + "' removed from : " + queueNames[queueIndex] + ". Seat number: " + queueSeats[queueIndex][seatIndex] + ".");
    }

    // Create a method called viewAllQueues.
    private static void viewAllQueues() {
        printSeatingAreas();
        for (int i = 0; i < queueNames.length; i++) {
            System.out.println("\n" + queueNames[i] + ":");
            if (queueCount[i] == 0) {
                System.out.println("No customers in the queue.");
            } else {
                for (int j = 0; j < queueCount[i]; j++) {
                    System.out.println("Seat " + queueSeats[i][j] + ": " + queueCustomers[i][j]);
                }
            }
        }
    }

    // Create a method called viewEmptyQueues.
    private static void viewEmptyQueues() {
        boolean allEmpty = true;
        for (int i = 0; i < queueNames.length; i++) {
            if (queueCount[i] > 0) {
                allEmpty = false;
                break;
            }
        }
        printSeatingAreas();
        if (allEmpty) {
            System.out.println("All queues are empty.");
        } else {
            for (int i = 0; i < queueNames.length; i++) {
                if (queueCount[i] == 0) {
                    System.out.println(queueNames[i] + " is empty.");
                }
            }
        }
    }

    // Create a method called removeServedCustomer.
    private static void removeServedCustomer(Scanner scanner) {
        System.out.print("Enter customer name: ");
        String CustomerName = scanner.next();


        boolean servedCustomerRemoved = false;

        for (int i = 0; i < queueNames.length; i++) {
            for (int j = 0; j < queueCount[i]; j++) {
                if (queueCustomers[i][j] != null && queueCustomers[i][j].equals(CustomerName)) {
                    queueCustomers[i][j] = null;
                    queueSeats[i][j] = 0;
                    queueCount[i]--;

                    if (stock >= BURGERS_PER_CUSTOMER) {
                        stock -= BURGERS_PER_CUSTOMER;
                        servedCustomerRemoved = true;
                    } else {
                        System.out.println("Insufficient stock to remove served customer.");
                        return;
                    }

                    printSeatingAreas();
                    break;
                }
            }
            if (servedCustomerRemoved) {
                System.out.println("Served Customer '" + CustomerName + "' removed from " + queueNames[i] + ".");
                return;
            }
        }

        System.out.println("Customer not found in any queue.");
    }

    // Create a method called sortCustomer.
    private static void sortCustomers() {
        // Assuming queueNames, queueCount, and queueCustomers are already defined.

// Calculate the total number of customers.
        int totalCustomers = 0;
        for (int count : queueCount) {
            totalCustomers += count;
        }

        if (totalCustomers == 0) {
            System.out.println("No customers in the queues.");
            return;
        }

// Create a new array to store all the customers.
        String[] customers = new String[totalCustomers];

// Copy customers from queueCustomers to the new array.
        int index = 0;
        for (int i = 0; i < queueNames.length; i++) {
            for (int j = 0; j < queueCount[i]; j++) {
                customers[index] = queueCustomers[i][j];
                index++;
            }
        }

// Sort the customers array.
        Arrays.sort(customers);

// Print the sorted customers.
        System.out.println("Customers in alphabetical order");
        for (String customer : customers) {
            System.out.println(customer);
        }
    }

    // Create a method called storeProgramData.
    private static void storeProgramData() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("food_center_data.txt"))) {
            writer.write("Stock: " + stock);
            writer.newLine();
            writer.write("Queue 1: " + queue1);
            writer.newLine();
            writer.write("Queue 2: " + queue2);
            writer.newLine();
            writer.write("Queue 3: " + queue3);
            writer.newLine();

            System.out.println("Stored program data into file Successfully.");
        } catch (IOException e) {
            System.out.println("Error storing program data to file: " + e.getMessage());
        }
    }


    // Create a method called loadProgramData.
    private static void loadProgramData() {
        try (FileReader fileReader = new FileReader("food_center_data.txt");
             BufferedReader bufferedReader = new BufferedReader(fileReader)) {

            String line;
            int burgerStock = 0;
            int queueUpdate = 0;

            while ((line = bufferedReader.readLine()) != null) {
                if (line.startsWith("Burger Stock: ")) {
                    burgerStock = Integer.parseInt(line.substring(14));
                    System.out.println("Burger Stock: " + burgerStock);
                } else if (line.startsWith("Queue Update: ")) {
                    queueUpdate = Integer.parseInt(line.substring(14));
                    System.out.println("Queue Update: " + queueUpdate);
                }
            }

            System.out.println("load program data from file Successfully!");
        } catch (IOException e) {
            System.out.println("ERROR while loading data: " + e.getMessage());
        }
    }

    // Create a method called viewRemainingBurgerStock.
    private static void viewRemainingBurgerStock() {
        System.out.println("Remaining burger stock: " + stock);
        if (stock < LOW_STOCK_THRESHOLD) {
            System.out.println("Warning: Stock is low (" + stock + " burgers remaining).");
        }
    }

    // Create a method called addBurgersToStock.
    private static void addBurgersToStock() {

        System.out.print("Enter the number of burgers to add: ");
        Scanner scanner = new Scanner(System.in);
        int burgersToAdd = scanner.nextInt();
        if (stock + burgersToAdd > 50) {
            System.out.println("Cannot add more than 50 burgers to stock.");
            return;
        }
        stock += burgersToAdd;
        System.out.println("Stock updated. Total burgers in stock: " + stock);
    }
}